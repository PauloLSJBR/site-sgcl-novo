# Site SGCL limpo

Versão reconstruída do site SGCL sem CSS injetado por JavaScript.

## Estrutura

- `index.html`: conteúdo e estrutura da landing page.
- `acesso-aplicativos.html`: página de acesso ao sistema.
- `css/styles.css`: todo o visual do site.
- `js/main.js`: somente comportamento: menu mobile, rolagem, active, voltar ao topo e formulário.
- `assets/`: imagens SVG incluídas no pacote.

## Regras desta versão

- Menu sem dropdown.
- CSS fica somente no CSS.
- JavaScript não cria estilos, não altera o card Sobre nós e não reescreve rodapé.
- Rodapé mantido no mesmo padrão do site atual.

## Teste local

```powershell
python -m http.server 8080
```

Abrir:

```text
http://localhost:8080
http://localhost:8080/acesso-aplicativos.html
```

## Substituição por imagens oficiais

Os arquivos em `assets/` são SVGs internos para o pacote funcionar sozinho.
Se quiser usar as imagens oficiais atuais, substitua mantendo os nomes ou ajuste os caminhos no HTML/CSS.
